<?php


/**
 * License Key Activation/Deactivation Class
 */

class CC_TK_License_Manager {

	/**
	 * Self Upgrade Values
	 */
	// Base URL to the remote upgrade API server
	public $upgrade_url = 'http://localhost/toddlahman/';

	/**
	 * @var string
	 */
	public $version = '0.1';

	/**
	 * @var string
	 */
	public $cc_tk_version_name = 'cc_tk_license_options_version';

	/**
	 * @var string
	 */
	public $plugin_url;

	/**
	 * @var string
	 */
	public $text_domain = 'cc_tk_example';

	public function __construct() {

		// Run the activation function
		if ( get_option( 'cc_tk_license_options' ) === false ) {
			$this->activation();
		}

		if ( is_admin() ) {

			// Performs activations and deactivations of API License Keys
			require_once( get_template_directory() . '/classes/class-cc-tk-key-api.php' );

			// Checks for software updatess
			require_once( get_template_directory() . '/classes/class-cc-tk-plugin-update.php' );

			// Admin menu with the license key and license email form
			require_once( get_template_directory() . '/admin/class-cc-tk-license-menu.php' );

			// Load update class to update $this plugin from for example toddlahman.com
			$this->load_plugin_self_updater();

		}


	}

	public function plugin_url() {
		if ( isset( $this->plugin_url ) ) return $this->plugin_url;
		return $this->plugin_url = get_template_directory_uri() . '/';
	}

	/**
	 * Check for software updates
	 */
	public function load_plugin_self_updater() {
		$options = get_option( 'cc_tk_license_options' );

		$upgrade_url = $this->upgrade_url; // URL to access the Update API Manager.
		$plugin_name = 'cc_tk'; // same as plugin slug. if a theme use a theme name like 'twentyeleven'
		$product_id = get_option( 'cc_tk_product_id' ); // Software Title
		$api_key = $options['api_key']; // API License Key
		$activation_email = $options['activation_email']; // License Email
		$renew_license_url = 'https://www.toddlahman.com/my-account'; // URL to renew a license
		$instance = get_option( 'cc_tk_instance' ); // Instance ID (unique to each blog activation)
		$domain = site_url(); // blog domain name
		$software_version = get_option( $this->cc_tk_version_name ); // The software version
		$plugin_or_theme = 'theme'; // 'theme' or 'plugin'
		// $this->text_domain is used to defined localization for translation

		new CC_TK_Update_API_Check( $upgrade_url, $plugin_name, $product_id, $api_key, $activation_email, $renew_license_url, $instance, $domain, $software_version, $plugin_or_theme, $this->text_domain );
	}


	/**
	 * Generate the default data arrays
	 */
	public function activation() {
		global $wpdb;

		$global_options = array(
			'api_key' 			=> '',
			'activation_email' 	=> '',
					);

		update_option( 'cc_tk_license_options', $global_options );

		require_once( get_template_directory() . '/classes/class-cc-tk-passwords.php' );

		$cc_tk_password_management = new CC_TK_Password_Management();

		// Generate a unique installation $instance id
		$instance = $cc_tk_password_management->generate_password( 12, false );

		$single_options = array(
			'cc_tk_product_id' 				=> 'My Theme Title',
			'cc_tk_instance' 				=> $instance,
			'cc_tk_deactivate_checkbox' 	=> 'on',
			'cc_tk_activated' 				=> 'Deactivated',
			);

		foreach ( $single_options as $key => $value ) {
			update_option( $key, $value );
		}

		$curr_ver = get_option( $this->cc_tk_version_name );

		// checks if the current plugin version is lower than the version being installed
		if ( version_compare( $this->version, $curr_ver, '>' ) ) {
			// update the version
			update_option( $this->cc_tk_version_name, $this->version );
		}

	}

} // End of class

$GLOBALS['cc_tk_license_manager'] = new CC_TK_License_Manager();
