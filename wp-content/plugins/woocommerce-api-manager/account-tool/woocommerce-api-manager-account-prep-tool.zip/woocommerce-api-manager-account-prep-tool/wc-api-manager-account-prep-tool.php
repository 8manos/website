<?php
/*
Plugin Name: WooCommerce API Manager Account Prep Tool
Plugin URI: http://www.toddlahman.com/
Description: Setup the API data for each product before activating this tool. Builds the user_meta order data for existing accounts for use with the WooCommerce Upgrade API Manager.
Version: 1.0
Author: Todd Lahman LLC
Author URI: http://www.toddlahman.com/
License: GPLv3

	Copyright 2011-2013 Todd Lahman LLC

	Intellectual Property rights reserved by Todd Lahman, LLC as allowed by law incude,
	but are not limited to, the working concept, function, and behavior of this plugin,
	the logical code structure and expression as written. All WordPress functions, objects, and
	related items, remain the property of WordPress under GPLv2 (or later), and any WordPress core
	functions and objects in this plugin operate under the GPLv2 (or later) license.
*/

/**
 * INSTRUCTIONS:
 *
 * Before using this tool, install and activate the API Manager, then setup the API data in each product, and save,
 * to be sure the required data exists before this tool runs.
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Simple Comments Class
 */
class API_Manager_Account_Prep_Tool {

	public $order_id;


	public function __construct() {

		// Run the activation function
		register_activation_hook( __FILE__, array( $this, 'activation' ) );

	}

	public function activation() {
		global $wpdb;

		//Populates an array containing the ID of every user
		$id = $wpdb->get_col("
			SELECT ID
			FROM wp_users
		" );

		// Remove all wc_am_orders data so it can be rebuilt
		if ( ! empty( $id ) ) {

			foreach ( $id as $key => $user_id ) {

				delete_user_meta( $user_id, $wpdb->get_blog_prefix() . 'wc_am_orders' );

			}

			$order_items = $wpdb->get_results("
				SELECT 		order_item_id, order_item_name, order_item_type, order_id
				FROM 		{$wpdb->prefix}woocommerce_order_items
				ORDER BY 	order_item_id
			", ARRAY_A );

			if ( ! empty( $order_items ) ) {

				foreach ( $order_items as $key => $order ) {

					/**
					 * $order contains numerically indexed arrays like this:
					 *
					 * Array
					 * (
					 *   [order_item_id] => 1
					 *   [order_item_name] => My Product
					 *   [order_item_type] => line_item
					 *   [order_id] => 4724
					 * )
					 *
					 */

					if ( count( $order ) > 0 ) {

						// Order ID
						$this->order_id = $order['order_id'];

						// order_id is the post_id
						$order_meta = get_post_custom( $this->order_id );

						if ( ! empty( $order_meta  ) )
							$user_id = $order_meta['_customer_user'][0];

						if ( ! empty( $user_id  ) )
							$user_meta = self::get_users_data( $user_id );

						if ( isset( $user_meta ) && ! empty( $user_meta ) ) {

							if ( self::array_search_multi( $user_meta, 'order_id', $this->order_id ) === true )
								continue; // skip duplicate order ids

						}

						$item_meta_product_id = $this->get_item_meta_product_id( $order['order_item_id'] );

						$item_meta_variation_id = $this->get_item_meta_variation_id( $order['order_item_id'] );

						$product_id = ( ! empty( $item_meta_variation_id ) ) ? $item_meta_variation_id : $item_meta_product_id;

						if ( empty( $product_id ) )
							continue; // skip this order if no download permission

						$product_meta = get_post_custom( $product_id );

						if ( empty( $product_meta ) )
							continue; // skip this order if no order meta data exists

						$software_title = ( ! empty( $product_meta['_api_software_title_var'][0] ) ) ? $product_meta['_api_software_title_var'][0] : $product_meta['_api_software_title_parent'][0];

						if ( empty( $software_title ) )
							continue; // skip this order if no order meta data exists

						$is_variable_product = ( ! empty( $product_meta['_api_software_title_var'][0] ) ) ? 'yes' : 'no';

						if ( empty( $is_variable_product ) )
							continue; // skip this order if no order meta data exists

				        $meta_data =
				        		array( $order_meta['_order_key'][0] =>
				        			array(
					                	'user_id'						=> absint( $user_id ),
										'order_id' 						=> absint( $this->order_id ),
										'order_key' 					=> sanitize_text_field( $order_meta['_order_key'][0] ),
										'license_email' 				=> empty( $order_meta['_billing_email'][0] ) ? '' : sanitize_text_field( $order_meta['_billing_email'][0] ),
										'_api_software_title_parent' 	=> empty( $product_meta['_api_software_title_parent'][0] ) ? '' : sanitize_text_field( stripslashes_deep( $product_meta['_api_software_title_parent'][0] ) ),
										'_api_software_title_var' 		=> empty( $product_meta['_api_software_title_var'][0] ) ? '' : sanitize_text_field( stripslashes_deep( $product_meta['_api_software_title_var'][0] ) ),
										'software_title' 				=> sanitize_text_field( stripslashes_deep( $software_title ) ),
										'parent_product_id'				=> empty( $product_meta['parent_product_id'][0] ) ? '' : sanitize_text_field( $product_meta['parent_product_id'][0] ),
										'variable_product_id'			=> empty( $product_meta['variable_product_id'][0] ) ? '' : sanitize_text_field( $product_meta['variable_product_id'][0] ),
										'current_version'				=> empty( $product_meta['_api_new_version'][0] ) ? '' : sanitize_text_field( stripslashes_deep( $product_meta['_api_new_version'][0] ) ),
										'_api_activations'				=> empty( $product_meta['_api_activations'][0] ) ? '' : absint( $product_meta['_api_activations'][0] ),
										'_api_activations_parent'		=> empty( $product_meta['_api_activations_parent'][0] ) ? '' : absint( $product_meta['_api_activations_parent'][0] ),
										'_api_update_permission'		=> 'yes',
										'is_variable_product'			=> sanitize_text_field( stripslashes_deep( $is_variable_product ) ),
										'license_type'					=> '',
										'expires'						=> '',
										)
				        			);

						self::save_meta_data( $meta_data, $order_meta['_order_key'][0] );

					}

				} // end foreach $order_items

			} // end if $order_items

		} // end if $id

	}

	public static function save_meta_data( $data, $order_key ) {
		global $wpdb;

		$current_info = self::get_users_data( $data[$order_key]['user_id'] );

		if ( ! empty( $current_info ) ) {

			$new_info = self::array_merge_recursive_associative( $data, $current_info );

			update_user_meta( $data[$order_key]['user_id'], $wpdb->get_blog_prefix() . 'wc_am_orders', $new_info );

		} else {

			update_user_meta( $data[$order_key]['user_id'], $wpdb->get_blog_prefix() . 'wc_am_orders', $data );

		}

	}

	/**
	 * Get order item meta.
	 *
	 * @access public
	 * @param mixed $item_id
	 * @return void
	 */
	public function get_item_meta_product_id( $order_item_id ) {
		global $wpdb;

		$item_meta = $wpdb->get_var( $wpdb->prepare( "
			SELECT 		meta_value
			FROM 		{$wpdb->prefix}woocommerce_order_itemmeta
			WHERE 		order_item_id = %d
			AND 		meta_key = '_product_id'
		", $order_item_id ) );

		return $item_meta;
	}

	/**
	 * Get order item meta.
	 *
	 * @access public
	 * @param mixed $item_id
	 * @return void
	 */
	public function get_item_meta_variation_id( $order_item_id ) {
		global $wpdb;

		$item_meta = $wpdb->get_var( $wpdb->prepare( "
			SELECT 		meta_value
			FROM 		{$wpdb->prefix}woocommerce_order_itemmeta
			WHERE 		order_item_id = %d
			AND 		meta_key = '_variation_id'
		", $order_item_id ) );

		return $item_meta;
	}

	/**
	 * Gets the user order info stored in an array for the $user_id, aka $object_id
	 *
	 * @since 1.0
	 * @param $user_id int
	 * @return array
	 */
	public static function get_users_data( $user_id = 0 ) {
		global $wpdb;

		if ( $user_id === 0 ) {
			$data = array();
			return $data;
		}

		$data = get_metadata( 'user', $user_id, $wpdb->get_blog_prefix() . 'wc_am_orders', true );

		if( empty( $data ) )
			$data = array();

		return $data;
	}

	/**
	 * array_search_multi Finds if a value matched with a needle exists in a multidimensional array
	 * @param  array $array  multidimensional array (for simple array use array_search)
	 * @param  mixed $value  value to search for
	 * @param  mixed $needle needle that needs to match value in array
	 * @since 1.0
	 * @return boolean
	 */
	public static function array_search_multi( $array, $value, $needle ) {

		foreach( $array as $index_key => $value_key ) {

			if ( $value_key[$value] === $needle ) return true;

		}

		return false;
	}

	/**
	 * Merges arrays recursively with an associative key
	 * To merge arrays that are numerically indexed use the PHP array_merge_recursive() function
	 *
	 * @since 1.0
	 * @param $array1 Array
	 * @param $array2 Array
	 * @return array
	 */
	public static function array_merge_recursive_associative( $array1, $array2 ) {

		$merged_arrays = $array1;

		if ( is_array( $array2 ) ) {
			foreach ( $array2 as $key => $val ) {
				if ( is_array( $array2[$key] ) ) {
					$merged_arrays[$key] = ( isset( $merged_arrays[$key] ) && is_array( $merged_arrays[$key] ) ) ? self::array_merge_recursive_associative( $merged_arrays[$key], $array2[$key] ) : $array2[$key];
				} else {
					$merged_arrays[$key] = $val;
				}
			}
		}

		return $merged_arrays;
	}

} // End of class

new API_Manager_Account_Prep_Tool();
